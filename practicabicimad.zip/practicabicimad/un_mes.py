#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pyspark.sql import SparkSession

from collections import Counter

import json
from pprint import pprint


from datetime import datetime

import sys

spark = SparkSession.builder.getOrCreate()
sc = spark.sparkContext


def get_data(line): 
    data = json.loads(line)
    origen = data["idunplug_station"]
    destino = data["idplug_station"]
    if origen < destino:
        trayecto = (origen, destino)
    else:
        trayecto = (destino, origen)
    fecha = datetime.strptime(data['unplug_hourTime'], "%Y-%m-%dT%H:%M:%SZ")
    day = fecha.weekday()
    if day <= 4:
        semana = "Entre semana" 
    else:
        semana = "Fin de semana" 
    hora = fecha.hour
    return ((semana,hora),trayecto)

def get_repetitions(lista):
    return Counter(lista).most_common() 
    #Para cada semana y hora ordena por los recorridos más usados y las veces que se repiten

def ordenar(lista):
    return sorted(lista,key = lambda x: x[0])
    #Ordenamos la lista por horas, desde las 0 hasta las 23

def get_string(lista):
    texto = ""
    for x in lista:
        texto = texto + "hora: "+str(x[0])+"  recorrido:  "+str(x[1][0])+" veces "+str(x[1][1])+"\n"
    return(texto)
    #Escribimos cada tupla como un string para luego copiarlo en el fichero de salida

def main(sc,filename):
    file_rdd = sc.textFile(filename).map(get_data) #Obtener lista de tuplas ((semana, hora),estaciones)
    agrupados = file_rdd.groupByKey() #Agrupa por semana y hora
    datos = agrupados.mapValues(get_repetitions).mapValues(lambda x: x[0]) #El ultimo map para coger solo el más común
    agrupa_dias = datos.map(lambda x: (x[0][0],(x[0][1],x[1]))).groupByKey().mapValues(list) #Agrupamos por días de la semana
    ordenado = agrupa_dias.mapValues(ordenar).mapValues(get_string).collect()
    for x in ordenado:
        print(str(x[0])+"\n")
        print(x[1])

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Uso: python3 {0} <file>".format(sys.argv[0]))
    else:
        main(sc,sys.argv[1])