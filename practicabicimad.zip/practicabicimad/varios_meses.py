from pyspark.sql import SparkSession
from collections import Counter
import json
from datetime import datetime
import sys


def get_data(line): 
    data = json.loads(line)
    origen = data["idunplug_station"]
    destino = data["idplug_station"]
    #Ordenamos los recorridos lexicográficamente
    if origen < destino:
        trayecto = (origen, destino)
    else:
        trayecto = (destino, origen)
    fecha = datetime.strptime(data['unplug_hourTime'], "%Y-%m-%dT%H:%M:%SZ")
    hora = fecha.hour
    mes = fecha.month
    return ((hora,mes), trayecto)

def get_repetitions(lista):
    return Counter(lista).most_common() 
    #Para cada semana y hora ordena por los recorridos más usados y las veces que se repiten

def ordenar(lista):
    return sorted(lista,key = lambda x: x[0])
    #Ordenamos la lista por horas, desde las 0 hasta las 23
    
def get_string(lista):
    texto = ""
    for x in lista:
        texto = texto + "Hora: "+str(x[0])+"  recorrido:  "+str(x[1][0])+" veces "+str(x[1][1])+"\n"
    return(texto)
    #Escribimos cada tupla como un string para luego copiarlo en el fichero de salida

def get_month(numero):
    if numero == 1:
        mes = 'Enero'
    elif numero == 2:
        mes = 'Febrero'
    elif numero == 3:
        mes = 'Marzo'
    elif numero == 4:
        mes = 'Abril'
    elif numero == 5:
        mes = 'Mayo'
    elif numero == 6:
        mes = 'Junio'
    elif numero == 7:
        mes = 'Julio'
    elif numero == 8:
        mes = 'Agosto'
    elif numero == 9:
        mes = 'Septiembre'
    elif numero == 10:
        mes = 'Octubre'
    elif numero == 11:
        mes = 'Noviembre'
    else:
        mes = 'Diciembre'
    return mes

def main(sc,files):
    rdd = sc.parallelize([])
    for file_name in files:        
        file_rdd = sc.textFile(file_name)
        rdd = rdd.union(file_rdd)        
    agrupados =rdd.map(get_data).groupByKey() #Obtener lista de tuplas ((semana, hora),estaciones) y agrupar por semana y hora
    datos = agrupados.mapValues(get_repetitions) #Obtener las repeticiones de cada recorrido para cada tipo de día y hora
    datos2 = datos.mapValues(lambda x: x[0]) #Cogemos el más concurrido
    datos3 = datos2.map(lambda x: ((x[0][1]),(x[0][0],x[1]))).groupByKey().sortByKey() #Ordenamos para agrupar por tipo de día y hora
    datos4 = datos3.mapValues(list).mapValues(ordenar)#Ordenamos por horas
    datos5 = datos4.mapValues(get_string).collect()
    for x in datos5:
        mes = get_month(x[0])
        print("Mes:"+mes+"\n")
        print(x[1])

    
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python3 {0} <file>".format(sys.argv[0]))
    else:
        l = []
        for i in range(1,len(sys.argv)):
            l.append(sys.argv[i])

        spark = SparkSession.builder.getOrCreate()
        sc = spark.sparkContext
        main(sc,l)